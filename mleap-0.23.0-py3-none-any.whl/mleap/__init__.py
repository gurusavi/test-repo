from mleap.version import version

__version__ = version